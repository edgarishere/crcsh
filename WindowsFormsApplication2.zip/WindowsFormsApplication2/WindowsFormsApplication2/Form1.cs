﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        int tr = 0;
        int rp = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\db111.mdf;Integrated Security=True;User Instance=True");
            String sql = "insert into datatb values('" + textBox1.Text +"','" + textBox2.Text + "')";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            loaddata();
        }
        public void loaddata()
        {
            SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\db111.mdf;Integrated Security=True;User Instance=True");
            String sql = "select * from datatb";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\db111.mdf;Integrated Security=True;User Instance=True");
            String sql = "update datatb set unm='" + textBox2.Text + "' where id='" + textBox1.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            loaddata();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            loaddata();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\db111.mdf;Integrated Security=True;User Instance=True");
            String sql = "delete from datatb where id='" + textBox1.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            loaddata();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\db111.mdf;Integrated Security=True;User Instance=True");
            String sql = "select * from datatb";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            rp = 0;
            textBox1.Text = dt.Rows[rp][0].ToString();
            textBox2.Text = dt.Rows[rp][1].ToString();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\db111.mdf;Integrated Security=True;User Instance=True");
            String sql = "select * from datatb";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
          tr = dt.Rows.Count - 1;
           rp = tr;
            textBox1.Text = dt.Rows[rp][0].ToString();
            textBox2.Text = dt.Rows[rp][1].ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\db111.mdf;Integrated Security=True;User Instance=True");
            String sql = "select * from datatb";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
          
            rp++;
            textBox1.Text = dt.Rows[rp][0].ToString();
            textBox2.Text = dt.Rows[rp][1].ToString();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\db111.mdf;Integrated Security=True;User Instance=True");
            String sql = "select * from datatb";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            rp--;
            textBox1.Text = dt.Rows[rp][0].ToString();
            textBox2.Text = dt.Rows[rp][1].ToString();
        }

    }
}
